import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="flex gap-4 p-4 bg-purple-600 text-white">
      <Link to="/">Accueil</Link>
      <Link to="/add">Ajouter</Link>
      <Link to="/transactions">Transactions</Link>
      <Link to="/reminders">Rappels</Link>
      <Link to="/dashboard">Dashboard</Link>
    </nav>
  );
}

export default Navbar;
