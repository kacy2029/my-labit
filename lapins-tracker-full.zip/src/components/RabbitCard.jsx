import { Link } from "react-router-dom";

function RabbitCard({ rabbit }) {
  return (
    <div className="p-4 bg-white rounded-xl shadow-md hover:shadow-lg transition">
      <h3 className="text-xl font-bold">{rabbit.name}</h3>
      <p>Sexe: {rabbit.gender}</p>
      <p>Date de naissance: {rabbit.birthDate}</p>
      <Link to={"/rabbit/" + rabbit.id} className="text-blue-500 mt-2 block">Voir Détail</Link>
    </div>
  );
}

export default RabbitCard;
