# Lapins Tracker 🐇

Gestion complète d'élevage de lapins :
- Suivi des lapins
- Rappels automatiques
- Gestion des ventes
- Dashboard de statistiques
- Recharts
- Firebase pour la base de données
